<?php
$server="localhost";
$username="root";
$password="";
$database="web2";

$conn=mysqli_connect($server, $username, $password, $database);

?>