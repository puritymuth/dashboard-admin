<?php
require_once('logics/dbconnection.php');
$queryUser = mysqli_query($conn, "SELECT * FROM enrollment WHERE no='".$_GET['id']."'");
while($fetchUser = mysqli_fetch_array($queryUser))
{
	$id=$fetchUser['no'];
	$fullName= $fetchUser['fullName'];
	$phonenumber= $fetchUser['phonenumber'];
	$emailaddress= $fetchUser['emailaddress'];
	$gender= $fetchUser['gender'];
	$course= $fetchUser['course'];
}

//update user records
if( isset($_POST['UpdateRecords']))
{
	//fetch form data
	$Name =$_POST['fullName'];
	$phoneNumber =$_POST['phonenumber'];
	$emailAddress =$_POST['emailaddress'];
	$formgender =$_POST['gender'];
	$formcourse =$_POST['course'];

	//update records
	$updatequery = mysqli_query($conn, "UPDATE enrollment SET fullName='$Name', phonenumber='$phoneNumber', emailaddress='$emailAddress', gender='$formgender', course='$formcourse' WHERE no='".$_GET['id']."'");
	if($updatequery)
	{
		echo "Data updated";
	}
	else{
		echo "Error occured";
	}
}
?>
<!DOCTYPE html>
<html>
<?php require_once('includes/headers.php')?>
<body>
	<!-- All our code. write here   -->
	<?php require_once('includes/navbar.php')?>
	<div class="sidebar">
	<?php require_once('includes/sidebar.php')?>
	</div>
	<div class="main-content">
		<div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header bg-dark text-center text-white">
                            <h4>Edit Student:  </h4>
                        </div>
						<div class="card-body">
							<form action="edit-enrollment.php?id=<?php echo $id?>" method="POST">
								<div class="row">

									<div class="mb-4 col-lg-3">
										<label for="fullName" class="form-label"><b>Full Name</b></label>
										<input type="text" name="fullName" class="form-control" value="<?php echo $fullName?>" placeholder="Please enter your full name ">
									</div >
									<div class="mb-4 col-lg-3">
										<label for="phoneNumber" class="form-label"><b>Phone Number</b></label>
										<input type="text" name="phonenumber" value="<?php echo $phonenumber?>" class="form-control" placeholder="+2547.........">
									</div>
								</div>
								<div class="row">
									<div class="mb-4 col-lg-3">
										<label for="emailaddress" class="form-label"><b>Email Address</b></label>
										<input type="text" name="emailaddress" class="form-control" value="<?php echo $emailaddress?>" placeholder="Please enter your email ">
									</div >
								   <div class="mb-4 col-lg-3">
									    <label for="gender" class="form-label"><b>Whats your Gender</b></label>
										<select class ="form-select form-control" name="gender"  arial-label ="Default select example">
											<option selected><?php echo $gender?></option>
											<option value="Male">Male</option>
											<option value="Female">Female</option>
										</select>
								    </div>
								</div>
									<div class="mb-4 col-lg-3">
										<label for="course" class="form-label"><b>Whats your preferred course</b></label>
										<select class ="form-select form-control" name="course"  arial-label ="Default select example">
											<option selected><?php echo $course?></option>
											<option value="Web Design ">Web Design</option>
											<option value="Web Development">Web Development</option>
											<option value="Anroid Development">Anroid Development</option>
										</select>
									</div>
								<div class="row pt-3">
									<div class="col-lg-6">
								        <button type="submit" name="UpdateRecords" class="btn btn-outline-primary">Update</button>
									</div>
								</div>
								</div>
                            </form>
						</div>
                    </div>
                </div>
            </div>
		</div>
	</div>
   
	<?php require_once('includes/scripts.php')?>

</body>
</html>