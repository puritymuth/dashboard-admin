<?php
//database connection//
require_once('logics/dbconnection.php');
$sqlFetchStudent=mysqli_query($conn,
    "SELECT * FROM contactus  WHERE no ='".$_GET['id']."'");
while($sqlFetchStudentrecords=mysqli_fetch_array($sqlFetchStudent))
{
    $firstName =$sqlFetchStudentrecords['firstname'];
    $lastName =$sqlFetchStudentrecords['lastname'];
    $phonenumber =$sqlFetchStudentrecords['phonenumber'];
    $email =$sqlFetchStudentrecords['email'];
    $message =$sqlFetchStudentrecords['message'];
    $created_at=$sqlFetchStudentrecords['created_at'];
}

?>
<!DOCTYPE html>
<html>
<?php require_once('includes/headers.php')?>
<body>
	<!-- All our code. write here   -->
	<?php require_once('includes/navbar.php')?>

	<div class="sidebar">
    <?php require_once('includes/sidebar.php')?>

	</div>
	<div class="main-content">
    <!-- to mantain the style -->
		<div class="container-fluid">
            <div class="row">
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header bg-dark text-white text-center">
                            <h4 class="card-title">personal information</h4>
                        </div>
                        <div class="card-body">
                            <ul class="list-group">
                                <li class="list-group-item">First Name: <span class="float-right badge badge-primary"><?php echo$firstName?></span></li>
                                <li class="list-group-item">Last Name: <span class="float-right badge badge-primary"><?php echo$lastName?></span></li>
                                <li class="list-group-item">Email: <span class="float-right badge badge-secondary"><?php echo$email?></span></li>
                                <li class="list-group-item">Phone number: <span class="float-right badge badge-danger"><?php echo$phonenumber?></span></li>
                            </ul>
                        </div>
		            </div>
                </div> 
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header bg-dark text-white text-center">
                            <h4 class="card-title">other information</h4>
                        </div>
                        <div class="card-body">
                            <ul class="list-group">
                                <li class="list-group-item">message <span class="float-right badge badge-primary"><?php echo$message?></span></li>
                                <li class="list-group-item">created_at <span class="float-right badge badge-danger"><?php echo$created_at?></span></li>
                            </ul>
                    </div>
		        </div>		
	        </div>
        </div>
    </div>
</div>    
	
	<?php require_once('includes/scripts.php')?>
</body>
</html>