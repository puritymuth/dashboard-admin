<nav>
			<ul>
				<li>
					<a href="index.php">
						<span><i class="fa fa-home"></i></span>
						<span>Dashboard</span>
					</a>
				</li>
				<li>
					<a href="students.php">
						<span><i class="fa fa-group"></i></span>
						<span>Students</span>
					</a>
				</li>
				<li>
					<a href="">
						<span><i class="fa fa-folder-open"></i></span>
						<span>course</span>
					</a>
				</li>
				<li>
					<a href="">
						<span><i class="fa fa-graduation-cap"></i></span>
						<span>campus</span>
					</a>
				</li>
				<li>
					<a href="contactus.php">
						<span><i class="fa fa-envelope"></i></span>
						<span>Messages</span>
				</li>
			</ul>
</nav>