<div class="header">
		
		<a href="index.php" ><span><img src ="images/download.png" alt="Zalego" class="navbar-trigger rounded-circle" height="50" width="50"></span></a>
	</div>